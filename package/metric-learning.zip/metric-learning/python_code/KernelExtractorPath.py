import numpy as np
import KernelExtractor


class VarTracker:
    """
    Maintains a dictionary that counts the number of times variables have been selected.
    """
    def __init__(self):
        self.tracker = dict()
        self.ranker = dict()
        self.worst_rank = 0

    def update(self, new_vars):

        old_vars = np.array([*self.tracker.keys()], dtype=np.int)
        only_in_old = old_vars[np.invert(np.isin(old_vars, new_vars))]

        # update count of number of times a variable is seen
        for var in new_vars:
            self.tracker[var] = self.tracker.get(var, 0) + 1

        # update the rank of a variable (smaller rank = more important)
        for rr in range(len(new_vars)):
            self.ranker[new_vars[rr]] = self.ranker.get(new_vars[rr], self.worst_rank) + rr

        for var in only_in_old:
            self.ranker[var] = self.ranker[var] + len(new_vars)

        self.worst_rank += len(new_vars)

    def filter(self, cutoff):
        return dict((k, v) for k, v in self.tracker.items() if v > cutoff)

    def filter_and_rank(self, cutoff):
        filtered = np.array([*self.filter(cutoff=cutoff)], dtype=np.int)
        rankings = np.zeros(len(filtered))

        for ii in range(len(rankings)):
            rankings[ii] = self.ranker[filtered[ii]]

        return filtered[np.argsort(rankings)]

class MetricPath:
    """
    Object to manage training of metric paths.
    """

    def __init__(self):

        self.times_in_path = VarTracker()

    def _update_tracker(self, new_vars):
        self.times_in_path.update(new_vars)

    def get_selected_vars(self, times_seen_cutoff=1):
        return self.times_in_path.filter(times_seen_cutoff)

    def get_selected_vars_as_array(self, times_seen_cutoff=1):
        # return variables that were selected strictly greater than the cutoff number of times
        return np.sort(np.array([*self.get_selected_vars(times_seen_cutoff=times_seen_cutoff)], dtype=np.int))

    def get_ranked_var_list(self, times_seen_cutoff=1):
        return self.times_in_path.filter_and_rank(cutoff=times_seen_cutoff)

    def reset_var_tracker(self):
        self.times_in_path = VarTracker()

    def run_paths(self, num_paths, screener, **kwargs):
        """
        Run metric path for num_paths number of times returning a list of the variables
        selected by each path. Automatically tracks the number of times each variable has
        been selected.
        :param num_paths: Number of paths to run.
        :param screener: Object of class MetricLearner
        :param kwargs: Arguments to _learn_metric_path.
        :return: List of lists. Each element list contains the variables selected for a single path.
        """

        chosen_vars = []
        for num in range(num_paths):
            screener.reset()  # reset MetricLearner before starting next path
            chosen_vars.append(_learn_metric_path(screener=screener, **kwargs))
            self._update_tracker(chosen_vars[num])

        return chosen_vars


def _multiple_try_screener(screener, num_tries, num_seen_cutoff=1, **kwargs):
    var_tracker = VarTracker()
    for num in range(num_tries):
        if not kwargs.get('warm_start'):
            screener.reset_beta()  # reset beta between tries (warm_starts tend to get stuck)
        screener.train(**kwargs)
        var_tracker.update(screener.get_vars())

    return np.array([*var_tracker.filter(num_seen_cutoff).keys()]).astype(np.int)


def _update_balancing_weight(y, phat, w):
    """
    Computes balancing weight update from response vector and predicted probabilities.
    Weight gets multiplied by 1-phat if y = 1 and multiplied by phat if y = 0 (thereby
    upweighting incorrectly classified observations).
    :param y: Binary numpy array of responses. Values are either 0 or 1.
    :param phat: Numpy array of same length as y giving P(Y=1|x).
    :param w: Numpy array of same length as y. Weight vector to be updated.
    :return: Updated weight vector
    """
    u = y*(1-phat) + (1-y)*phat
    w = w*u
    return w/np.sum(w)


def _update_adaboost_weight(y, phat, w, learning_rate=1):
    """
    Computes adaboost weight update from response vector and predicted probabilities.
    :param y: Binary numpy array of responses. Values are either 0 or 1.
    :param phat: Numpy array of same length as y giving P(Y=1|x).
    :param w: Numpy array of same length as y. Weight vector to be updated.
    :param learning_rate: Learning rate for adaboost.
    :return: Updated weight vector
    """

    ptrunc = np.clip(phat, a_min=1e-8, a_max=1-1e-8) # truncate for numerical stability

    u = (-0.5*(2*y-1)*np.log(ptrunc/(1-ptrunc)))*learning_rate
    u = u - np.max(u) # for stability subtract off the max, otherwise exponential function may explode
    w = w*np.exp(u)
    return w/np.sum(w)


def _logit(p):

    ptrunc = np.clip(p, a_min=1e-8, a_max=1 - 1e-8)
    return np.log(ptrunc/(1-ptrunc))


def _expit(eta):
    return 1/(1+np.exp(-eta))


def _shrink_pi_hat(pi_hat, pi_hat_bound):

    eta_hat = _logit(pi_hat)
    eta_bound = np.abs(_logit(pi_hat_bound))
    eta_max = np.max(np.abs(eta_hat))

    if eta_max < eta_bound:
        return pi_hat
    else:
        eta_hat = (eta_hat / np.max(np.abs(eta_hat))) * eta_bound
        return _expit(eta_hat)


def _update_weight(y, phat, w, weight_update):
    """
    Wrapper function to call either balancing weight update or adaboost weight udate.
    """

    if weight_update == 'adaboost':
        return _update_adaboost_weight(y=y, phat=phat, w=w)
    elif weight_update == 'balancing':
        return _update_balancing_weight(y=y, phat=phat, w=w)
    else:
        raise ValueError("Unrecognized choice of weight update.")


def _define_subgroup(sampled_features, chosen_var):
    """
    Returns the indices of the chosen variables with respect to the set of sampled features.
    In the case of an empty intersection, returns None.
    """
    # no variables selected so far
    if len(chosen_var) == 0:
        return None

    # no variables selected among the sampled features
    if sampled_features is None:
        return chosen_var

    return np.where(np.isin(sampled_features, chosen_var))[0]


def _subsample_features(X, feature_fraction, always_include=np.array([], dtype=np.int)):
    """
    Subsamples a fraction of the columns of X.
    :param X: feature matrix
    :param feature_fraction: fraction of indices to sample
    :param always_include: column indices of features that should always be included
    :return: Xsub which is the subsampled matrix, sampled_features which includes the indices of the sampled columns
    """

    assert feature_fraction > 0, "Fraction of features to sample must be > 0."

    if feature_fraction == 1:
        return X, None
    else:
        num_sampled_features = int(np.ceil(feature_fraction*X.shape[1]))
        sampled_features = np.random.choice(X.shape[1], size=num_sampled_features, replace=False)
        sampled_features = np.union1d(sampled_features, always_include)
        return X[:, sampled_features], sampled_features


def _get_top_k(var_ids, scores, take_top_k=None):

    if take_top_k is None:
        return var_ids

    return var_ids[np.argsort(-scores)][:np.min([take_top_k, len(var_ids)])]


def _update_var_list(sorted_list, var_ids, scores, take_top_k=None):

    if len(var_ids) == 0:
        return sorted_list

    var_ids = var_ids[np.argsort(-scores)]  # rank by scores
    if take_top_k is not None:
        var_ids = var_ids[:np.min([take_top_k, len(var_ids)])]
    new_bool = np.invert(np.isin(var_ids, sorted_list))
    new_vars = var_ids[new_bool]

    print("New variables: ", new_vars)

    sorted_list = np.concatenate([sorted_list, new_vars])

    return sorted_list


def _learn_metric_path(screener, model, X, class_p, lam, num_tries=4, num_seen_cutoff=1, max_iter=5000,
                       max_rounds=50, beta_init='random', verbose=False, zero_tol=1e-6, convergence_tol=1e-4,
                       warm_start=False, subsample_feature=1, hierarchical=False, init_value=None,
                       hier_upper=3, subgroup_lower=None, subgroup_upper=None, weight_update='balancing',
                       subsample_data=1, sample_weight=None, take_top_k=None, dual_init=0.0, min_times_on_path=1,
                       pi_hat_bound=0.52, target_num_var=np.Infinity, warmup=100, penalty_decrease_factor=0.95):

    var_counter = VarTracker()

    if hierarchical:
        assert init_value is not None, "If hierarchical search, initial value for active set coefficients must be set."
        beta_init = 'zero'
        subgroup_lower = init_value
        subgroup_upper = init_value*hier_upper

    subgroup_var = None

    if subsample_data < 1:
        sub_id = np.random.choice(X.shape[0], size=int(np.ceil(subsample_data * X.shape[0])), replace=False)
        X = X[sub_id,:]
        class_p = class_p[sub_id]
        if sample_weight is not None: sample_weight = sample_weight[sub_id]

    if sample_weight is None:
        #w = np.ones(X.shape[0]) / X.shape[0]  # initialize equal weight
        w = class_p * 1/np.sum(class_p) + (1-class_p) * 1/np.sum(1-class_p)
        w = w / np.sum(w)
    else:
        assert len(sample_weight) == X.shape[0], "Sample weight vector must be same dimension as number of rows of X."
        w = sample_weight

    # subsample variables
    Xsub, sampled_features = _subsample_features(X, subsample_feature)

    # run the supplied screening algorithm
    var_id = _multiple_try_screener(screener=screener, num_tries=num_tries, num_seen_cutoff=num_seen_cutoff,
                                    X=Xsub, class_p=class_p, sample_weight=w, max_iter=max_iter, lam=lam,
                                    beta_init=beta_init, zero_tol=zero_tol, convergence_tol=convergence_tol,
                                    subgroup=subgroup_var, warm_start=warm_start, dual_init=dual_init, warmup=warmup)

    # keep track of chosen variables as an integer array
    chosen_var = np.array([], dtype=np.int)
    scores = screener.beta[var_id]
    if subsample_feature < 1:
        var_id = sampled_features[var_id]
    top_k_vars = _get_top_k(var_ids=var_id, scores=scores, take_top_k=take_top_k)
    var_counter.update(top_k_vars)
    chosen_var = _update_var_list(sorted_list=chosen_var, var_ids=var_id, scores=scores, take_top_k=take_top_k)
    selected = np.array([*var_counter.filter(cutoff=np.min([max_rounds - 1, min_times_on_path]))], dtype=np.int)

    if verbose:
        print("Coefficients: ", np.round(-np.sort(-screener.beta[var_id]), decimals=2))

    if verbose:
        print("Total of %d variables selected so far. Variables selected in round %d: "
              % (len(chosen_var), 0), var_id[np.argsort(-scores)], flush=True)

    # terminate if no variables are chosen and no sub-sampling of features is performed
    if len(var_id) == 0 and subsample_feature == 1:
        if target_num_var < np.Infinity:
            lam *= penalty_decrease_factor  # decrease penalty
            print("Decreasing value of lambda to %f because target number of variables has not been reached." % lam)
        else:
            return chosen_var

    round_num = 1
    while round_num < max_rounds:

        # Reweight the sample
        if len(chosen_var) > 0:
            if len(top_k_vars) > 0:
                pi_hat = model.fit(X=X[:, top_k_vars], y=class_p, sample_weight=w).predict_proba(X[:, top_k_vars])[:, 1]
            else:
                pi_hat = model.fit(X=X[:, chosen_var], y=class_p, sample_weight=w).predict_proba(X[:, chosen_var])[:, 1]

            pi_hat = _shrink_pi_hat(pi_hat=pi_hat, pi_hat_bound=pi_hat_bound)

            if verbose:
                print("Smallest fitted probability: ", np.round(np.min(pi_hat), decimals=2))
                print("Largest fitted probability: ", np.round(np.max(pi_hat), decimals=2))

            w = _update_weight(y=class_p, phat=pi_hat, w=w, weight_update=weight_update)

        # subsample variables
        Xsub, sampled_features = _subsample_features(X, subsample_feature, always_include=chosen_var)

        # metric screening
        if hierarchical:
            # update subgroup (index with respect to sampled features)
            subgroup_var = _define_subgroup(sampled_features, chosen_var)
            beta_init = np.zeros(X.shape[1]) if subsample_feature == 1 else np.zeros(len(sampled_features))
            beta_init[subgroup_var] = init_value

        var_id = _multiple_try_screener(screener=screener, num_tries=num_tries, num_seen_cutoff=num_seen_cutoff,
                                        X=Xsub, class_p=class_p, sample_weight=w, max_iter=max_iter, lam=lam,
                                        beta_init=beta_init, zero_tol=zero_tol, convergence_tol=convergence_tol,
                                        subgroup=subgroup_var, subgroup_lower=subgroup_lower,
                                        subgroup_upper=subgroup_upper, warm_start=warm_start, dual_init=dual_init,
                                        warmup=warmup)

        if verbose:
            print("Coefficients of selected variables: ", np.round(-np.sort(-screener.beta[var_id]), decimals=2),
                  flush=True)

        # terminate if hierarchical and all weights remain at initial values
        if hierarchical and (np.sum(screener.beta) < (np.sum(beta_init) + 1e-4)):
            break

        # terminate if no variable chosen and no sub-sampling has been performed
        if len(var_id) == 0 and subsample_feature == 1:
            if target_num_var < np.Infinity:
                lam *= 0.98  # decrease penalty
                print("Decreasing value of lambda to %f because target number of variables has not been reached." % lam)
            else:
                break

        scores = screener.beta[var_id]
        if subsample_feature < 1:
            var_id = sampled_features[var_id]
        top_k_vars = _get_top_k(var_ids=var_id, scores=scores, take_top_k=take_top_k)
        var_counter.update(top_k_vars)
        chosen_var = _update_var_list(sorted_list=chosen_var, var_ids=var_id, scores=scores, take_top_k=take_top_k)

        #if len(var_id) > 0:
        #    new_vars = var_id if subsample_feature == 1 else sampled_features[var_id]
        #    chosen_var = np.union1d(chosen_var, new_vars).astype(np.int)

        if verbose: print("Total of %d variables selected so far. Variables selected in round %d: "\
                          % (len(chosen_var), round_num), var_id[np.argsort(-scores)], flush=True)

        round_num += 1

        selected = np.array([*var_counter.filter(cutoff=np.min([max_rounds - 1, min_times_on_path]))], dtype=np.int)
        if len(selected) >= target_num_var:
            break

    print("Variables selected without filtering: ", chosen_var)
    print("Variables selected after filtering: ", selected, flush=True)

    return selected
