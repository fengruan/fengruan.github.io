import numpy as np
from sklearn import linear_model
from sklearn.svm import l1_min_c
from sklearn.model_selection import KFold
from sklearn.model_selection import GroupKFold


def find_topK_lasso(target_active, model, X, y, c_grid=None, penalty_scale=100, len_grid=100):
    if c_grid is None:
        c_grid = l1_min_c(X=X, y=y, loss='log') * np.logspace(0, np.log10(penalty_scale), len_grid)

    for c in c_grid:
        model.set_params(C=c)
        model.fit(X,y)
        num_active = np.sum(model.coef_ != 0)
        if num_active >= target_active:
            break

    return np.argsort(-np.abs(model.coef_.squeeze()))[:target_active]


def fit_logistic_path(model, X, y, c_grid=None, penalty_scale=100, len_grid=100, max_var=None,\
                      predict=True, Xtes=None):

    assert type(model) == linear_model._logistic.LogisticRegression, "Model must be sklearn logistic regression."
    if predict: assert Xtes is not None, "Test features cannot be none if predicting."

    if c_grid is None:
        c_grid = l1_min_c(X=X, y=y, loss='log') * np.logspace(0, np.log10(penalty_scale), len_grid)

    yhat = np.empty((Xtes.shape[0],0), dtype=np.float64)
    coefs_ = []
    for c in c_grid:
        model.set_params(C=c)
        model.fit(X, y)
        coefs_.append(model.coef_.ravel().copy())
        if predict: yhat = np.append(yhat, model.predict(X=Xtes).reshape((-1,1)), axis=1)
        if (max_var is not None) and (np.sum(model.coef_ != 0.0) >= max_var): break

    coefs_ = np.transpose(np.vstack(coefs_))
    yhat = yhat.reshape((Xtes.shape[0],-1))

    return coefs_, yhat

def cv_logistic(model, X, y,  n_fold=10, penalty_scale=100,\
                len_grid=100, max_var=1e5, group_id=None,
                err_fun=lambda ytes, pred: np.mean(pred != ytes)):

    if group_id is None:
        kf = KFold(n_splits=n_fold)
    else:
        kf = GroupKFold(n_splits=n_fold)

    misclass_err = np.ones((n_fold, len_grid))
    fold = 0

    c_grid = l1_min_c(X=X, y=y, loss='log')*np.logspace(0, np.log10(penalty_scale), len_grid)

    for tr_id, tes_id in kf.split(X=X, y=y, groups=group_id):
        xtr = X[tr_id, :]; ytr = y[tr_id]
        xtes = X[tes_id, :]; ytes = y[tes_id]

        if (np.mean(ytr) == 0) or (np.mean(ytr) == 1):
            continue

        _, yhat = fit_logistic_path(model=model, X=xtr, y=ytr, c_grid=c_grid,\
                                    penalty_scale=penalty_scale, len_grid=len_grid,\
                          max_var=max_var, predict=True, Xtes=xtes)

        misclass_err[fold,:] = np.apply_along_axis(lambda pred: err_fun(ytes, pred),\
                                                   axis=0, arr=yhat)
        fold += 1

    return c_grid, np.mean(misclass_err, axis=0)


def cv_fit(X, y, n_fold=10, penalty_scale=25, len_grid=25, tol=1e-4,\
           max_iter=int(1e3), warm_start=True):

    logreg = linear_model.LogisticRegression(penalty='l1', solver='liblinear', tol=tol, \
                                             max_iter=max_iter, warm_start=warm_start)
    c_grid, err = cv_logistic(logreg, X, y, n_fold=n_fold, penalty_scale=penalty_scale,\
                              len_grid=len_grid)
    chat = c_grid[np.argmin(err)]
    logreg.set_params(C=chat)
    logreg.fit(X=X, y=y)

    return logreg

