
# math and data manipulation
import pandas as pd
import numpy as np

import pickle
import scipy.stats
import sklearn.ensemble
from sklearn import linear_model
from sklearn.model_selection import ShuffleSplit
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC

# to handle paths
import sys
sys.path.insert(0, '../python_code/')
sys.path.insert(0, '../python_code/lasso/')
from pathlib import Path

import KernelExtractor
import KernelExtractorPath
import Permutation
import l1_logistic

jobid = sys.argv[1]
dataset_name = sys.argv[2]
frac_retain = float(sys.argv[3])

data_path = Path('..', 'data')
dataset_file = dataset_name + '.csv'
dat = pd.read_csv(data_path / 'madelon.csv')

x = dat.values[:,1:]
y = 1.0*dat.values[:,0]

print("Finished loading data...")

# transform the data using z-standardization

def z_transform(x):
    assert type(x) == np.ndarray, "Input should be numpy array."
    return scipy.stats.norm.ppf(np.apply_along_axis(scipy.stats.rankdata, 0, x)/ (x.shape[0] + 1))

x = z_transform(x)

scaler = StandardScaler()
x = scaler.fit_transform(x)

# simulation parameters
num_folds = 3
test_frac = 500/2600 # fraction of data to use for testing
kf = ShuffleSplit(n_splits=num_folds, test_size=test_frac)

num_models = 5

# metric learning parameters
batch_size = 150; max_iter = 5000
l1_bound = 1; subgroup_l1 = 0.75

max_rounds = 20; num_paths = 4; num_tries = 1; num_seen_cutoff = 0; warm_start=False

# adaboost update parameters
learning_rate=0.05; n_estimators=1; max_depth=6
weight_update = 'balancing'

# parameters for t-test screening and tree_screening
print("Retaining fraction of features: ", frac_retain)
num_retain = int(np.ceil(frac_retain*x.shape[1]))

# arrays to store simulation output
screening_methods = ['no-screening', 't-screen', 'lasso-screen', 'tree-screen', 'metric-screen']

num_chosen = np.zeros((num_folds, 2))
class_err = np.ones((num_folds, num_models, len(screening_methods)))

sim_results = dict()
sim_results['num_chosen'] = num_chosen
sim_results['class_err'] = class_err

print("Beginning simulations...")

import time

start = time.time()

fold = 0
for tr_index, tes_index in kf.split(X=x, y=y):
    
    xtr = x[tr_index,:]; ytr = y[tr_index]
    xtes = x[tes_index,:]; ytes = y[tes_index]

    # compute base error
    base_err = np.mean(ytes != 1*(np.mean(ytr) >= 0.5))
    
    # screen variable using metric learning
    extractor = KernelExtractor.MetricLearner(batch_size=150, penalty='user_defined',                                         subgroup_lower=0, subgroup_upper=1)

    grid, fp = Permutation.perm_false_positive(extractor, X=xtr, y=ytr, beta_init='equal')
    lam = Permutation.find_penalty(grid, fp/xtr.shape[1], fpr_cutoff= 0.025) # set penalty using permutation cutoff

    metric_path = KernelExtractorPath.MetricPath()
    gbm = sklearn.ensemble.GradientBoostingClassifier(n_estimators=n_estimators, learning_rate=learning_rate,                                                      max_depth=max_depth)
    var_list = metric_path.run_paths(num_paths=num_paths, screener=extractor, model=gbm, X=xtr,                                     class_p=ytr, num_tries=num_tries, num_seen_cutoff=num_seen_cutoff,                                     lam=lam, max_rounds=max_rounds,verbose=False,                                     init_value=5*lam, hierarchical=False, hier_upper=2,                                     warm_start=warm_start, beta_init = 'equal',                                    weight_update=weight_update)
    chosen_var_metric = metric_path.get_selected_vars_as_array(1)
    num_chosen[fold,0] = len(chosen_var_metric)
    print("%d variables chosen by metric learner out of %d total." % (len(chosen_var_metric), xtr.shape[1]))

    num_retain = len(chosen_var_metric)

    # screening with l1 logistic regression
    logreg = linear_model.LogisticRegression(penalty='l1', solver='saga', tol=1e-4,                                               max_iter=int(1e3), warm_start=True)
    c_grid, err = l1_logistic.cv_logistic(logreg, xtr, ytr, n_fold=10, penalty_scale=25, len_grid=25)
    chat = c_grid[np.argmin(err)]; logreg.set_params(C=chat); logreg.fit(X=xtr, y=ytr)
    class_err[fold,2,0] = np.mean(ytes != logreg.predict(xtes))
    chosen_var_lasso = np.where(logreg.coef_.squeeze() != 0.0)[0]
    num_chosen[fold,1] = len(chosen_var_lasso)
    print("%d variables chosen by lasso out of %d total." % (len(chosen_var_lasso), xtr.shape[1]))
       
    # screening using random forest variable importance
    rf = sklearn.ensemble.RandomForestClassifier(n_estimators=200, max_features='sqrt')
    rf.fit(X=xtr, y=ytr)
    class_err[fold,1,0] = np.mean(ytes != rf.predict(xtes))
    chosen_var_tree = np.argsort(rf.feature_importances_)[-num_retain:]
    
    # screening using t-statistic
    _, t_pval = scipy.stats.ttest_ind(xtr[ytr==0,:],xtr[ytr==1,:], axis=0)
    chosen_var_tstat = np.argsort(t_pval)[:num_retain]
    
    # logistic regression
    logreg = l1_logistic.cv_fit(xtr[:,chosen_var_tstat], ytr, n_fold=5, penalty_scale=25,                                len_grid=25)
    class_err[fold,2,1] = np.mean(ytes != logreg.predict(xtes[:,chosen_var_tstat]))
    
    if len(chosen_var_lasso) == 0:
        class_err[fold,2,2] = base_err
    else:
        logreg = l1_logistic.cv_fit(xtr[:,chosen_var_lasso], ytr, n_fold=5, penalty_scale=25,                                len_grid=25)
        class_err[fold,2,2] = np.mean(ytes != logreg.predict(xtes[:,chosen_var_lasso]))
        
    logreg = l1_logistic.cv_fit(xtr[:,chosen_var_tree], ytr, n_fold=5, penalty_scale=25,                                len_grid=25)
    class_err[fold,2,3] = np.mean(ytes != logreg.predict(xtes[:,chosen_var_tree]))
    logreg = l1_logistic.cv_fit(xtr[:,chosen_var_metric], ytr, n_fold=5, penalty_scale=25,                                len_grid=25)
    class_err[fold,2,4] = np.mean(ytes != logreg.predict(xtes[:,chosen_var_metric]))
   
    # gradient boosting
    gbm = sklearn.ensemble.GradientBoostingClassifier()
    gbm.fit(X=xtr, y=ytr)
    class_err[fold,0,0] = np.mean(ytes != gbm.predict(xtes))
    gbm.fit(X=xtr[:,chosen_var_tstat], y=ytr)
    class_err[fold,0,1] = np.mean(ytes != gbm.predict(xtes[:,chosen_var_tstat]))
    
    if len(chosen_var_lasso) == 0:
        class_err[fold,0,2] = base_err
    else:
        gbm.fit(X=xtr[:,chosen_var_lasso], y=ytr)
        class_err[fold,0,2] = np.mean(ytes != gbm.predict(xtes[:,chosen_var_lasso]))
        
    gbm.fit(X=xtr[:,chosen_var_tree], y=ytr)
    class_err[fold,0,3] = np.mean(ytes != gbm.predict(xtes[:,chosen_var_tree]))
    gbm.fit(X=xtr[:,chosen_var_metric], y=ytr)
    class_err[fold,0,4] = np.mean(ytes != gbm.predict(xtes[:,chosen_var_metric]))
   
    # random forest
    rf.fit(X=xtr[:,chosen_var_tstat], y=ytr)
    class_err[fold,1,1] = np.mean(ytes != rf.predict(xtes[:,chosen_var_tstat]))
    
    if len(chosen_var_lasso) == 0:
        class_err[fold,1,2] = base_err
    else:
        rf.fit(X=xtr[:,chosen_var_lasso], y=ytr)
        class_err[fold,1,2] = np.mean(ytes != rf.predict(xtes[:,chosen_var_lasso]))
    
    rf.fit(X=xtr[:,chosen_var_tree], y=ytr)
    class_err[fold,1,3] = np.mean(ytes != rf.predict(xtes[:,chosen_var_tree]))
    rf.fit(X=xtr[:,chosen_var_metric], y=ytr)
    class_err[fold,1,4] = np.mean(ytes != rf.predict(xtes[:,chosen_var_metric]))
    
    # neural network
    clf = MLPClassifier(max_iter=1000)
    clf.fit(X=xtr, y=ytr)
    class_err[fold,3,0] = np.mean(ytes != clf.predict(xtes))
    
    clf.fit(X=xtr[:,chosen_var_tstat], y=ytr)
    class_err[fold,3,1] = np.mean(ytes != clf.predict(xtes[:,chosen_var_tstat]))
    if len(chosen_var_lasso) == 0:
        class_err[fold,3,2] = base_err
    else:
        clf.fit(X=xtr[:,chosen_var_lasso], y=ytr)
        class_err[fold,3,2] = np.mean(ytes != clf.predict(xtes[:,chosen_var_lasso]))
    clf.fit(X=xtr[:,chosen_var_tree], y=ytr)
    class_err[fold,3,3] = np.mean(ytes != clf.predict(xtes[:,chosen_var_tree]))
    clf.fit(X=xtr[:,chosen_var_metric], y=ytr)
    class_err[fold,3,4] = np.mean(ytes != clf.predict(xtes[:,chosen_var_metric]))
    
    # svm
    svm = SVC()
    svm.fit(X=xtr,y=ytr)
    class_err[fold,4,0] = np.mean(ytes != svm.predict(xtes))
    
    svm.fit(X=xtr[:,chosen_var_tstat], y=ytr)
    class_err[fold,4,1] = np.mean(ytes != svm.predict(xtes[:,chosen_var_tstat]))
    if len(chosen_var_lasso) == 0:
        class_err[fold,4,2] = base_err
    else:
        svm.fit(X=xtr[:,chosen_var_lasso], y=ytr)
        class_err[fold,4,2] = np.mean(ytes != svm.predict(xtes[:,chosen_var_lasso]))
    svm.fit(X=xtr[:,chosen_var_tree], y=ytr)
    class_err[fold,4,3] = np.mean(ytes != svm.predict(xtes[:,chosen_var_tree]))
    svm.fit(X=xtr[:,chosen_var_metric], y=ytr)
    class_err[fold,4,4] = np.mean(ytes != svm.predict(xtes[:,chosen_var_metric]))
    
    with open('./results/' + dataset_name + str(jobid) + '.pickle', 'wb') as handle:
        pickle.dump(sim_results, handle)
        
    fold += 1 

end = time.time()
print(end - start)