# math and data manipulation
import pandas as pd
import numpy as np
import random
import pickle
import scipy.stats
import sklearn.ensemble
from sklearn import linear_model
from sklearn.svm import l1_min_c
from sklearn.model_selection import GroupShuffleSplit
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier

# to handle paths
import sys
sys.path.insert(0, '../python_code/')
sys.path.insert(0, '../python_code/lasso/')
from pathlib import Path

import KernelExtractor
import KernelExtractorPath
import Permutation
import l1_logistic

jobid = sys.argv[1]
target_num_var = int(sys.argv[2])
lam = float(sys.argv[3])
num_patients = int(sys.argv[4])

with open('../data/aden_normalized.pickle', 'rb') as f:
    dat = pickle.load(f)
x = dat[:, 1:]
y = dat[:, 0]

patid = pd.read_csv('../data/aden_patid.csv')
patid = patid.values.squeeze()

num_folds = 1

# split data by patients
kf = GroupShuffleSplit(n_splits=1000, test_size=1 - num_patients / len(np.unique(patid)))

num_models = 7

do_pca = False
num_components = 100

random_feature_subset = False
p = 200

make_cor_plot = False

# metric learning parameters
dual_init = 0.0
solver = 'dual average'
batch_size = 500;
max_iter = 20000
l1_bound = 2;
subgroup_l1 = 0.75
linf = np.Infinity
take_top_k = None
pi_hat_bound = 0.51
convergence_tol = 1e-3
min_times_on_path = 1
beta_init = 'equal'
penalty_decrease_factor = 0.9

subsample_prop = 1

max_rounds = 200;
num_paths = 1;
num_tries = 1;
num_seen_cutoff = 0;
warm_start = True
warmup = 100

# adaboost update parameters
learning_rate = 0.1;
n_estimators = 10;
max_depth = 6
weight_update = 'balancing'

# arrays to store simulation output
screening_methods = ['no-screening', 't-screen', 'lasso-screen', 'tree-screen', 'metric-screen', 'oracle']

screeners_switch = dict()
screeners_switch['no-screening'] = True
screeners_switch['t-screen'] = True
screeners_switch['lasso-screen'] = False
screeners_switch['tree-screen'] = True
screeners_switch['metric-screen'] = True
screeners_switch['oracle'] = False

screeners_id = dict()
idx = 0
for s in screening_methods:
    screeners_id[s] = idx
    idx += 1

chosen_var = dict()
for screener in screening_methods:
    chosen_var[screener] = []

model_names = ['logistic', 'tree', 'gbm', 'rf', 'nnet', 'svm', 'knn']


class LogisticModel:

    def __init__(self):
        self.model = None

    def fit(self, X, y):
        self.model = l1_logistic.cv_fit(X, y, n_fold=5, penalty_scale=25, len_grid=25)

    def predict(self, X):
        return self.model.predict(X)


models = dict()
# models['logistic'] = LogisticModel()
models['logistic'] = sklearn.linear_model.LogisticRegression()
models['tree'] = DecisionTreeClassifier()
models['gbm'] = sklearn.ensemble.GradientBoostingClassifier()
models['rf'] = sklearn.ensemble.RandomForestClassifier(n_estimators=50, n_jobs=-1)
models['nnet'] = MLPClassifier(hidden_layer_sizes=(100,100,), max_iter=2000)
models['svm'] = SVC()
models['knn'] = KNeighborsClassifier(p=2)

models_switch = dict()
models_switch['logistic'] = True
models_switch['tree'] = False
models_switch['gbm'] = False
models_switch['rf'] = True
models_switch['nnet'] = True
models_switch['svm'] = False
models_switch['knn'] = False

models_id = dict()
idx = 0
for m in model_names:
    models_id[m] = idx
    idx += 1

class_err = np.ones((0, len(model_names), len(screening_methods)))
num_chosen = np.zeros((0, 2))
base_err = np.zeros((0,))
var_intersect = np.zeros((0, len(screening_methods), len(screening_methods)))
metric_screen_time = []

tmp_err = np.ones((1, len(model_names), len(screening_methods)))
tmp_chosen = np.zeros((1, 2))
tmp_intersect = np.zeros((1, len(screening_methods), len(screening_methods)))


def balanced_err(ytes, pred):
    id0 = (ytes == 0)
    id1 = (ytes == 1)

    err0 = np.mean(ytes[id0] != pred[id0]) if np.sum(id0) > 0 else 0
    err1 = np.mean(ytes[id1] != pred[id1]) if np.sum(id1) > 0 else 0

    return (err0 + err1) / 2


def assess_model_with_screening(xtr, ytr, xtes, ytes, model, chosen_var, default_err):
    if len(chosen_var) == 0:
        return default_err
    model.fit(X=xtr[:, chosen_var], y=ytr)
    # return np.mean(ytes != model.predict(X=xtes[:, chosen_var]))
    return balanced_err(ytes, model.predict(X=xtes[:, chosen_var]))


fold = 0
import time

start_sim = time.time()

for tr_index, tes_index in kf.split(x, y, groups=patid):
    if fold == num_folds:
        break

    acceptable_subsample = False

    ytr = y[tr_index]
    ytes = y[tes_index]

    print("patients in training set: ", np.unique(patid[tr_index]))

    if (np.mean(ytr) > 0.1) and (np.mean(ytr) < 0.9) and (len(ytr) > 4000):
        acceptable_subsample = True

    if not acceptable_subsample:
        continue

    if do_pca:
        print("Performing PCA...")
        pca = decomposition.PCA(n_components=num_components, whiten=True)
        pca.fit(xtr)
        xtr = pca.transform(xtr)
        xtes = pca.transform(xtes)

    if random_feature_subset:
        sample_var = np.random.choice(x.shape[1], size=p, replace=False)
        xtr = x[tr_index, :][:, sample_var]
        xtes = x[tes_index, :][:, sample_var]
    else:
        xtr = x[tr_index, :]
        xtes = x[tes_index, :]

    print(xtr.shape)
    print(xtes.shape)

    # screen down to 100 features
    # rf_screener = sklearn.ensemble.RandomForestClassifier(n_estimators=50, n_jobs=-1)
    # rf_screener.fit(X=xtr, y=ytr)
    # _, t_pval = scipy.stats.ttest_ind(xtr[ytr==0,:],xtr[ytr==1,:], axis=0)
    # logreg = linear_model.LogisticRegression(penalty='l1', solver='liblinear', tol=1e-3,\
    #                                           max_iter=int(1e3), warm_start=True)
    # initial_screen = l1_logistic.find_topK_lasso(200, model=logreg, X=xtr, y=ytr)
    # initial_screen = np.argsort(t_pval)[:100]
    # initial_screen = np.argsort(rf_screener.feature_importances_)[-20:]
    # xtr = xtr[:,initial_screen]
    # xtes = xtes[:,initial_screen]

    chosen_var['no-screening'] = np.arange(0, xtr.shape[1], 1)

    # compute base error
    base_err = np.append(base_err, balanced_err(ytes, np.ones(len(tes_index)) * 1 * (np.mean(ytr) >= 0.5)))
    print("base error: ", base_err[fold])

    # screen variable using metric learning
    if screeners_switch['metric-screen']:
        print("Performing metric screening...")

        extractor = KernelExtractor.MetricLearner(batch_size=batch_size, penalty='user_defined', solver=solver,
                                                  subgroup_lower=0, subgroup_upper=1, linf_constraint=linf,
                                                  l1_constraint=l1_bound, param_update_frac=1)

        # grid, fp = Permutation.perm_false_positive(extractor, X=xtr, y=ytr, beta_init='equal')
        # lam = Permutation.find_penalty(grid, fp/xtr.shape[1], fpr_cutoff= 0.025) # set penalty using permutation cutoff

        metric_path = KernelExtractorPath.MetricPath()
        gbm = sklearn.ensemble.GradientBoostingClassifier(n_estimators=n_estimators, learning_rate=learning_rate,
                                                          max_depth=max_depth)

        start = time.time()
        var_list = metric_path.run_paths(num_paths=num_paths, screener=extractor, model=gbm, X=xtr, class_p=ytr,
                                         num_tries=num_tries, num_seen_cutoff=num_seen_cutoff, lam=lam,
                                         max_rounds=max_rounds, verbose=True, init_value=5 * lam, hierarchical=False,
                                         hier_upper=3, warm_start=warm_start, beta_init=beta_init,
                                         weight_update=weight_update, max_iter=max_iter, subsample_data=subsample_prop,
                                         convergence_tol=convergence_tol, take_top_k=take_top_k, dual_init=dual_init,
                                         min_times_on_path=min_times_on_path, pi_hat_bound=pi_hat_bound,
                                         target_num_var=target_num_var, warmup=warmup, penalty_decrease_factor=penalty_decrease_factor)
        end = time.time()
        metric_screen_time += [end - start]

        chosen_var['metric-screen'] = metric_path.get_selected_vars_as_array(0)
        print("Converged in : ", extractor.iters)
        # chosen_var['metric-screen'] = initial_screen[metric_path.get_selected_vars_as_array(1)]
        # print("variables chosen by metric-screen: ", chosen_var['metric-screen'])
        # print("variables from initial screening: ", metric_path.get_selected_vars_as_array(1))
        # print("variables from initial screening: ", initial_screen)
        tmp_chosen[0, 1] = len(chosen_var['metric-screen'])

        print("%d variables chosen by metric learner out of %d total." % (len(chosen_var['metric-screen']), xtr.shape[1]))

        num_retain = len(chosen_var['metric-screen'])

    if len(chosen_var['metric-screen']) == 0:
        continue

    # screening with l1 logistic regression
    if screeners_switch['lasso-screen']:
        logreg = linear_model.LogisticRegression(penalty='l1', solver='liblinear', tol=1e-3, max_iter=int(1e3),
                                                 warm_start=True)
        c_grid, err = l1_logistic.cv_logistic(logreg, xtr, ytr, n_fold=5, penalty_scale=25, len_grid=25,
                                              group_id=patid[tr_index], err_fun=balanced_err)
        chat = c_grid[np.argmin(err)];
        logreg.set_params(C=chat);
        logreg.fit(X=xtr, y=ytr)
        chosen_var['lasso-screen'] = np.where(logreg.coef_.squeeze() != 0.0)[0]
        tmp_chosen[0, 0] = len(chosen_var['lasso-screen'])

        print("%d variables chosen by lasso out of %d total." % (len(chosen_var['lasso-screen']), xtr.shape[1]))

    # screening using random forest variable importance
    if screeners_switch['tree-screen']:
        print("tree-screening in progress...")
        models['rf'].fit(X=xtr, y=ytr)
        chosen_var['tree-screen'] = np.argsort(models['rf'].feature_importances_)[-num_retain:]
        # chosen_var['tree-screen'] = initial_screen[-num_retain:]

    # screening using t-statistic
    if screeners_switch['t-screen']:
        print("t-screening in progress...")
        # _, t_pval = scipy.stats.ttest_ind(xtr[ytr==0,:],xtr[ytr==1,:], axis=0)
        # chosen_var['t-screen'] = np.argsort(t_pval)[:num_retain]
        logreg = linear_model.LogisticRegression(penalty='l1', solver='liblinear', tol=1e-3, max_iter=int(1e3),
                                                 warm_start=True)
        chosen_var['t-screen'] = l1_logistic.find_topK_lasso(num_retain, model=logreg, X=xtr, y=ytr)

    print("Training models...")
    for screen in screening_methods:
        for mod in model_names:
            if screeners_switch[screen] and models_switch[mod]:
                col_id = screeners_id[screen]
                row_id = models_id[mod]
                tmp_err[0, row_id, col_id] = assess_model_with_screening(xtr, ytr, xtes, ytes, models[mod],
                                                                         chosen_var[screen], base_err[fold])

    for screen1 in screening_methods:
        for screen2 in screening_methods:
            if screeners_switch[screen1] and screeners_switch[screen2]:
                col_id = screeners_id[screen2]
                row_id = screeners_id[screen1]
                tmp_intersect[0, row_id, col_id] = len(np.intersect1d(chosen_var[screen1], chosen_var[screen2])) / len(
                    chosen_var[screen1]) if len(chosen_var[screen1]) > 0 else 0

    class_err = np.vstack([class_err, tmp_err])
    num_chosen = np.vstack([num_chosen, tmp_chosen])
    var_intersect = np.vstack([var_intersect, tmp_intersect])

    sim_results = dict()
    sim_results['num_chosen'] = num_chosen
    sim_results['class_err'] = class_err
    sim_results['base_err'] = base_err
    sim_results['var_intersect'] = var_intersect
    sim_results['metric_screen_time'] = metric_screen_time
    sim_results['take_top_k'] = take_top_k
    sim_results['pi_hat_bound'] = pi_hat_bound
    sim_results['min_times_on_path'] = min_times_on_path
    sim_results['penalty_decrease_factor'] = penalty_decrease_factor

    with open('./results/aden' + '_pat' + str(num_patients) + '_lam' + str(lam) + '_var' + str(target_num_var) + '_' + str(jobid) + '.pickle', 'wb') as handle:
        pickle.dump(sim_results, handle)

    print("Tree-screen Variables: ", chosen_var['tree-screen'])
    print("Metric-screen Variables: ", chosen_var['metric-screen'])
    print("Lasso Variables: ", chosen_var['t-screen'])

    if make_cor_plot and len(chosen_var['metric-screen']) > 1:
        cor_kernel = np.corrcoef(x[:, chosen_var['metric-screen']], rowvar=False)
        plt.hist(cor_kernel[np.triu_indices(len(chosen_var['metric-screen']), k=1)])
        plt.show()

        cor_tree = np.corrcoef(x[:, chosen_var['tree-screen']], rowvar=False)
        plt.hist(cor_tree[np.triu_indices(len(chosen_var['tree-screen']), k=1)])
        plt.show()

    print(tmp_err)

    fold += 1

end_sim = time.time()
print(end_sim - start_sim)