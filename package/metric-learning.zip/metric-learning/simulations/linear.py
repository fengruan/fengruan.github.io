
# math and data manipulation
import pandas as pd
import numpy as np

import pickle
import scipy.stats
import sklearn.ensemble
from sklearn import linear_model
from sklearn.model_selection import ShuffleSplit
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier


# to handle paths
import sys
sys.path.insert(0, '../python_code/')
sys.path.insert(0, '../python_code/lasso/')
from pathlib import Path

import KernelExtractor
import KernelExtractorPath
import l1_logistic
import Permutation

jobid = int(sys.argv[1])

n = 250
pgrid = np.array([10, 50, 100, 250, 500])
p = pgrid[jobid - 1]
ntes = 10000

num_folds = 100

num_models = 7

# metric learning parameters
batch_size = 500; max_iter = 50000
l1_bound = 1; subgroup_l1 = 0.75

max_rounds = 30; num_paths = 4; num_tries = 1; num_seen_cutoff = 0; warm_start=False

# adaboost update parameters
learning_rate=0.05; n_estimators=1; max_depth=6
weight_update = 'balancing'

# parameters for t-test screening and tree_screening
frac_retain = 0.04
num_retain = int(np.ceil(frac_retain*p))

# arrays to store simulation output
screening_methods = ['no-screening', 't-screen', 'lasso-screen', 'tree-screen', 'metric-screen', 'oracle']

screeners_switch = dict()
screeners_switch['no-screening'] = True
screeners_switch['t-screen'] = True
screeners_switch['lasso-screen'] = True
screeners_switch['tree-screen'] = True
screeners_switch['metric-screen'] = True
screeners_switch['oracle'] = True

screeners_id = dict()
idx = 0
for s in screening_methods:
    screeners_id[s] = idx
    idx += 1
    
chosen_var = dict()
for screener in screening_methods: 
    chosen_var[screener] = []
chosen_var['no-screening'] = np.arange(0, p, 1)

model_names = ['logistic', 'tree', 'gbm', 'rf', 'nnet', 'svm', 'knn']

class LogisticModel:
    
    def __init__(self):
        self.model = None
        
    def fit(self, X, y):
        self.model = l1_logistic.cv_fit(X, y, n_fold=5, penalty_scale=25, len_grid=25)
    
    def predict(self, X):
        return self.model.predict(X)

models = dict()
models['logistic'] = sklearn.linear_model.LogisticRegression()
models['tree'] = DecisionTreeClassifier()
models['gbm'] = sklearn.ensemble.GradientBoostingClassifier()
models['rf'] = sklearn.ensemble.RandomForestClassifier(n_estimators=50, max_features='auto')
models['nnet'] = MLPClassifier(max_iter=2000)
models['svm'] = SVC()
models['knn'] = KNeighborsClassifier(p=3)

models_switch = dict()
models_switch['logistic'] = True
models_switch['tree'] = False
models_switch['gbm'] = False
models_switch['rf'] = False
models_switch['nnet'] = True
models_switch['svm'] = True
models_switch['knn'] = False

models_id = dict()
idx = 0
for m in model_names:
    models_id[m] = idx
    idx += 1

def assess_model_with_screening(xtr, ytr, xtes, ytes, model, chosen_var, default_err):
    if len(chosen_var) == 0:
        return default_err
    model.fit(X=xtr[:, chosen_var], y=ytr)
    return np.mean(ytes != model.predict(X=xtes[:, chosen_var]))

s = 5
beta_true = 1/np.sqrt(np.linspace(1,s,s))*0.5
chosen_var['oracle'] = np.arange(0, 5, 1)

class_err = np.ones((0, len(model_names), len(screening_methods)))
num_chosen = np.zeros((0, 2))

tmp_err = np.ones((1, len(model_names), len(screening_methods)))
tmp_chosen = np.zeros((1, 2))

sim_results = dict()
sim_results['num_chosen'] = num_chosen
sim_results['class_err'] = class_err
sim_results['n'] = n
sim_results['p'] = p


import time

start = time.time()

for fold in range(num_folds):
    
    ytr = np.concatenate([np.ones(n//2), np.zeros(n//2)])
    ytes = np.concatenate([np.ones(ntes//2), np.zeros(ntes//2)])
    
    xtr = np.random.normal(size=(n,p))
    xtr[:,:s] = xtr[:,:s] + beta_true.reshape((1,s))*(2*ytr.reshape((n,1)) - 1)
    xtes = np.random.normal(size=(ntes,p))
    xtes[:,:s] = xtes[:,:s] + beta_true.reshape((1,s))*(2*ytes.reshape((ntes,1)) - 1)
    
    # compute base error
    base_err = np.mean(ytes != 1*(np.mean(ytr) >= 0.5))

    # screen variable using metric learning
    if screeners_switch['metric-screen']:
    
        extractor = KernelExtractor.MetricLearner(batch_size=batch_size, penalty='user_defined',                                         subgroup_lower=0, subgroup_upper=1, stepsize=1, solver='dual average')
    
        lam = 0.025*np.sqrt(np.log(p)/(n//2))
        
        metric_path = KernelExtractorPath.MetricPath()
        gbm = sklearn.ensemble.GradientBoostingClassifier(n_estimators=n_estimators, learning_rate=learning_rate,                                                      max_depth=max_depth)
        var_list = metric_path.run_paths(num_paths=num_paths, screener=extractor, model=gbm, X=xtr,                                     class_p=ytr, num_tries=num_tries, num_seen_cutoff=num_seen_cutoff,                                     lam=lam, max_rounds=max_rounds,verbose=True,                                     init_value=5*lam, hierarchical=False, hier_upper=2,                                     warm_start=warm_start, beta_init = 'zero',                                    weight_update=weight_update, max_iter=max_iter, convergence_tol=1e-3)
        chosen_var['metric-screen'] = metric_path.get_selected_vars_as_array(1)
        tmp_chosen[0, 1] = len(chosen_var['metric-screen'])
        
        print("%d variables chosen by metric learner out of %d total." % (len(chosen_var['metric-screen']), xtr.shape[1]))
    
        num_retain = len(chosen_var['metric-screen'])
    
    # screening with l1 logistic regression
    if screeners_switch['lasso-screen']:
        logreg = linear_model.LogisticRegression(penalty='l1', solver='liblinear', tol=1e-3,                                               max_iter=int(1e3), warm_start=True)
        c_grid, err = l1_logistic.cv_logistic(logreg, xtr, ytr, n_fold=10, penalty_scale=25, len_grid=25)
        chat = c_grid[np.argmin(err)]; logreg.set_params(C=chat); logreg.fit(X=xtr, y=ytr)
        chosen_var['lasso-screen'] = np.where(logreg.coef_.squeeze() != 0.0)[0]
        tmp_chosen[0, 0] = len(chosen_var['lasso-screen'])
        
        print("%d variables chosen by lasso out of %d total." % (len(chosen_var['lasso-screen']), xtr.shape[1]))

    # screening using random forest variable importance
    if screeners_switch['tree-screen']:
        models['rf'].fit(X=xtr, y=ytr)
        chosen_var['tree-screen'] = np.argsort(models['rf'].feature_importances_)[-num_retain:]
    
    # screening using t-statistic
    if screeners_switch['t-screen']:
        _, t_pval = scipy.stats.ttest_ind(xtr[ytr==0,:],xtr[ytr==1,:], axis=0)
        chosen_var['t-screen'] = np.argsort(t_pval)[:num_retain]
    
    for screen in screening_methods:
        for mod in model_names:
            if screeners_switch[screen] and models_switch[mod]:
                col_id = screeners_id[screen]
                row_id = models_id[mod]
                tmp_err[0, row_id, col_id] = assess_model_with_screening(xtr, ytr, xtes, ytes, models[mod],                                                                              chosen_var[screen], base_err)

    class_err = np.vstack([class_err, tmp_err])
    num_chosen = np.vstack([num_chosen, tmp_chosen])

    sim_results = dict()
    sim_results['num_chosen'] = num_chosen
    sim_results['class_err'] = class_err
    sim_results['n'] = n
    sim_results['p'] = p

    with open('./results/linear_p' + str(p) + '.pickle', 'wb') as handle:
        pickle.dump(sim_results, handle)

end = time.time()
print(end - start)