
# math and data manipulation
import pandas as pd
import numpy as np
import timeit
import random
import pickle
import scipy.stats
import sklearn.ensemble
from sklearn import linear_model
from sklearn.svm import l1_min_c
from sklearn.preprocessing import StandardScaler


# to handle paths
import sys
sys.path.insert(0, '../python_code/')
sys.path.insert(0, '../python_code/lasso/')

import KernelExtractor
import KernelExtractorPath
import l1_logistic

jobid = int(sys.argv[1])
p_id = int(sys.argv[2])
num_folds = int(sys.argv[3])

# ### Settings for Signal

s = 4

beta_main = np.array([0.25, 0.1, 0.2, 0.1])

beta_interact = np.array([0.5, 0.5])

n = 500
pgrid = np.array([50, 250, 500, 750, 1000])
p = pgrid[p_id]

# ### Settings for Metric Screening

# metric learning parameters
lam = 0.01
pi_hat_bound = 0.52
batch_size = 250; max_iter = 2000
l1_bound = 2; subgroup_l1 = 0.75
solver = 'sgd'
init_type = 'equal'
convergence_tol=1e-2
penalty_decrease_factor = 0.9
warmup = 1000
warm_start = True
stepsize = 2

def sq_diff(x):
    return np.power(x, 2)

take_top_k = None
min_times_on_path = 1
target_num_var = s

max_rounds = 100; 
num_paths = 1; 
num_tries = 1; 
num_seen_cutoff = 0; 
warm_start=False

# adaboost update parameters
learning_rate=0.05; n_estimators=6; max_depth=6
weight_update = 'balancing'


# ### Settings for Screening


# arrays to store simulation output
screening_methods = ['no-screening', 't-screen', 'lasso-screen', 'tree-screen', 'metric-screen', 'metric-rbf', 'oracle']

screeners_switch = dict()
screeners_switch['no-screening'] = False
screeners_switch['t-screen'] = True
screeners_switch['lasso-screen'] = True
screeners_switch['tree-screen'] = True
screeners_switch['metric-screen'] = True
screeners_switch['metric-rbf'] = False
screeners_switch['oracle'] = True

screeners_id = dict()
idx = 0
for screener in screening_methods:
    screeners_id[screener] = idx
    idx += 1
    
chosen_var = dict()
for screener in screening_methods: 
    chosen_var[screener] = []

chosen_var['oracle'] = np.arange(0, s, 1)


# ### Initialize Storage of Results

sim_results = dict()
sim_results['main effect'] = beta_main
sim_results['interaction'] = beta_interact
sim_results['n'] = n
sim_results['p'] = p
sim_results['simulation_name'] = "hierarchical interaction"

sim_results['lam'] = lam
sim_results['pi_hat_bound'] = pi_hat_bound
sim_results['batch_size'] = batch_size
sim_results['l1_bound'] = l1_bound
sim_results['solver'] = 'dual_average'
sim_results['init_type'] = 'zero'
sim_results['convergence_tol'] = convergence_tol
sim_results['penalty_decrease_factor'] = penalty_decrease_factor
sim_results['warmup'] = warmup
sim_results['warm_start'] = True
sim_results['stepsize'] = 2
sim_results['learning_rate'] = learning_rate
sim_results['n_estimators'] = n_estimators
sim_results['max_depth'] = max_depth
sim_results['weight_update'] = weight_update

# array to keep track of number of times each variable has been discovered
discover = np.zeros((len(screening_methods), s))


# ### Data generating mechanism


def generate_xy(n, p, s, beta_main, beta_interact):
    
    y = np.concatenate([np.ones(n//2), np.zeros(n//2)])
    x0 = np.random.normal(size=(n//2, p))
    x1 = np.random.normal(size=(n//2, p))
    
    main_eff = np.linspace(0, s-2, s//2, dtype=np.int)
    interact_eff = np.linspace(1, s-1, s//2, dtype=np.int)
    
    x0[:,main_eff] = x0[:,interact_eff]*beta_interact.reshape((1,-1)) + x0[:, main_eff] *    np.sqrt(1-np.power(beta_interact,2).reshape((1,-1)))
    x1[:,main_eff] = -x1[:,interact_eff]*beta_interact.reshape((1,-1)) + x1[:, main_eff] *    np.sqrt(1-np.power(beta_interact,2).reshape((1,-1)))
    x = np.vstack([x0,x1])
    x[:,:s] = x[:,:s] + beta_main.reshape((1,-1)) * (2*y.reshape((n,1)) - 1)
    
    return x, y


# ### Simulation Loop

import time
start = time.time()

for fold in range(num_folds):
    
    xtr, ytr = generate_xy(n=n, p=p, s=s, beta_main=beta_main, beta_interact=beta_interact)
 
    if screeners_switch['no-screening']:
        chosen_var['no-screening'] = np.arange(0, xtr.shape[1], 1)
    
    # screen variable using metric learning with Laplace kernel
    if screeners_switch['metric-screen']:
    
        extractor = KernelExtractor.MetricLearner(batch_size=batch_size, penalty='user_defined', solver=solver,                                                  l1_constraint=l1_bound, stepsize=stepsize)
    
        
        metric_path = KernelExtractorPath.MetricPath()
        gbm = sklearn.ensemble.GradientBoostingClassifier(n_estimators=n_estimators, learning_rate=learning_rate,                                                      max_depth=max_depth)

        var_list = metric_path.run_paths(num_paths=num_paths, screener=extractor, model=gbm, X=xtr,                                     class_p=ytr, num_tries=num_tries, num_seen_cutoff=num_seen_cutoff,                                     lam=lam, max_rounds=max_rounds,verbose=True,                                     init_value=5*lam, hierarchical=False, hier_upper=3,                                     warm_start=warm_start, beta_init = init_type,                                    weight_update=weight_update, max_iter=max_iter, convergence_tol=convergence_tol,                                        take_top_k=take_top_k, pi_hat_bound = pi_hat_bound,                                        target_num_var=target_num_var, warmup=warmup,                                        min_times_on_path=min_times_on_path)
        chosen_var['metric-screen'] = metric_path.get_selected_vars_as_array(0) 
        
        print("%d variables chosen by metric learner out of %d total." % (len(chosen_var['metric-screen']), xtr.shape[1]))
    
        num_retain = len(chosen_var['metric-screen'])
      
    # screen variable using metric learning with Gaussian kernel
    if screeners_switch['metric-rbf']:
        extractor = KernelExtractor.MetricLearner(batch_size=batch_size, penalty='user_defined', solver=solver,                                                  l1_constraint=l1_bound, stepsize=stepsize, diff=sq_diff)
    
        
        metric_path = KernelExtractorPath.MetricPath()
        gbm = sklearn.ensemble.GradientBoostingClassifier(n_estimators=n_estimators, learning_rate=learning_rate,                                                      max_depth=max_depth)
        
        var_list = metric_path.run_paths(num_paths=num_paths, screener=extractor, model=gbm, X=xtr,                                     class_p=ytr, num_tries=num_tries, num_seen_cutoff=num_seen_cutoff,                                     lam=lam, max_rounds=max_rounds,verbose=True,                                     init_value=5*lam, hierarchical=False, hier_upper=3,                                     warm_start=warm_start, beta_init = init_type,                                    weight_update=weight_update, max_iter=max_iter, convergence_tol=convergence_tol,                                        take_top_k=take_top_k, pi_hat_bound = pi_hat_bound,                                        target_num_var=target_num_var, warmup=warmup,                                        min_times_on_path=min_times_on_path)
        chosen_var['metric-rbf'] = metric_path.get_selected_vars_as_array(0)
        print("%d variables chosen by metric rbf out of %d total." % (len(chosen_var['metric-rbf']), xtr.shape[1]))
    
        # screening with l1 logistic regression
    if screeners_switch['lasso-screen']:
        logreg = linear_model.LogisticRegression(penalty='l1', solver='liblinear', tol=1e-3,                                               max_iter=int(1e3), warm_start=True)
        
        chosen_var['lasso-screen'] = l1_logistic.find_topK_lasso(num_retain, model=logreg, X=xtr, y=ytr)
       
        print("%d variables chosen by lasso out of %d total." % (len(chosen_var['lasso-screen']), xtr.shape[1]))

    # screening using random forest variable importance
    if screeners_switch['tree-screen']:
        rf = sklearn.ensemble.RandomForestClassifier(n_estimators=200)
        rf.fit(X=xtr, y=ytr)
        chosen_var['tree-screen'] = np.argsort(rf.feature_importances_)[-num_retain:]
    
    # screening using t-statistic
    if screeners_switch['t-screen']:
        _, t_pval = scipy.stats.ttest_ind(xtr[ytr==0,:],xtr[ytr==1,:], axis=0)
        chosen_var['t-screen'] = np.argsort(t_pval)[:num_retain]
    
    
    for screener in screening_methods:
        if screeners_switch[screener]: 
            discover[screeners_id[screener],:] += 1*np.array([k in chosen_var[screener] for k in chosen_var['oracle']])
    
    sim_results['discover'] = discover
    
    print("Tree-screen Variables: ", chosen_var['tree-screen'])
    print("Metric-screen Variables: ", chosen_var['metric-screen'])
    print("Metric-RBF Variables: ", chosen_var['metric-rbf'])
    print("Lasso Variables: ", chosen_var['lasso-screen'])
    
    with open('./results/hier_int_p' + str(p) + '_job' + str(jobid) + '.pickle', 'wb') as handle:
        pickle.dump(sim_results, handle)

end = time.time()
print(end - start)

