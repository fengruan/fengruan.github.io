# math and data manipulation
import pandas as pd
import numpy as np

import pickle
import scipy.stats
import sklearn.ensemble
from sklearn import linear_model
from sklearn.model_selection import ShuffleSplit
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC

# to handle paths
import sys
sys.path.insert(0, '../python_code/')
sys.path.insert(0, '../python_code/lasso/')
from pathlib import Path

import KernelExtractor
import KernelExtractorPath
import Permutation
import l1_logistic

jobid = sys.argv[1]
dataset_name = sys.argv[2]
frac_retain = sys.argv[3]

data_path = Path('..', 'data')
dataset_file = dataset_name + '.csv'
dat = pd.read_csv(data_path / dataset_file)

x = dat.values[:,1:]
y = 1.0*dat.values[:,0]

with open('./results/' + dataset_name + str(jobid) + '.pickle', 'wb') as handle:
        pickle.dump(x.shape, handle)

print(x.shape)
print("Retaining fraction of features: ", frac_retain)
print("Finished loading data...")
