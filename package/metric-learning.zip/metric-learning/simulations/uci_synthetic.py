# math and data manipulation
import pandas as pd
import numpy as np

import pickle
import scipy.stats
import sklearn.ensemble
from sklearn import linear_model
from sklearn.model_selection import ShuffleSplit
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier

# to handle paths
import sys
sys.path.insert(0, '../python_code/')
sys.path.insert(0, '../python_code/lasso/')
from pathlib import Path

import KernelExtractor
import KernelExtractorPath
import Permutation
import l1_logistic

jobid = sys.argv[1]
dataset_name = sys.argv[2]
p_ind_noise = int(sys.argv[3])
p_cor_noise = int(sys.argv[4])

data_path = Path('..', 'data')
dataset_file = dataset_name + '.csv'
dat = pd.read_csv(data_path / dataset_file)

x = dat.values[:,1:]
y = 1.0*dat.values[:,0]
y = np.array(y, dtype=np.float64)

def z_transform(x):
    assert type(x) == np.ndarray, "Input should be numpy array."
    return scipy.stats.norm.ppf(np.apply_along_axis(scipy.stats.rankdata, 0, x)/ (x.shape[0] + 1))

x = z_transform(x)

scaler = StandardScaler()
x = scaler.fit_transform(x)

max_n = 500  # maximum sample size of training set
rho = 0.75  # correlation when adding correlated variables

num_folds = 1
test_frac = 1- np.min([0.8*x.shape[0], max_n])/x.shape[0] # fraction of data to use for testing
kf = ShuffleSplit(n_splits=num_folds, test_size=test_frac)

num_models = 7

# metric learning parameters
pi_hat_bound = 0.51
batch_size = 500; max_iter = 2000
l1_bound = 2; subgroup_l1 = 0.75
solver = 'dual average'
convergence_tol=1e-2
target_num_var = 6
min_times_on_path = 1
lam = 0.01

max_rounds = 30; num_paths = 1; num_tries = 1; num_seen_cutoff = 0; warm_start=False

if p_cor_noise > 0:
    take_top_k = 2
else:
    take_top_k = None

# adaboost update parameters
learning_rate=0.1; n_estimators=10; max_depth=6
weight_update = 'balancing'

# arrays to store simulation output
screening_methods = ['no-screening', 't-screen', 'lasso-screen', 'tree-screen', 'metric-screen', 'oracle']

screeners_switch = dict()
screeners_switch['no-screening'] = True
screeners_switch['t-screen'] = True
screeners_switch['lasso-screen'] = True
screeners_switch['tree-screen'] = True
screeners_switch['metric-screen'] = True
screeners_switch['oracle'] = True

screeners_id = dict()
idx = 0
for s in screening_methods:
    screeners_id[s] = idx
    idx += 1

    
chosen_var = dict()
for screener in screening_methods: 
    chosen_var[screener] = []


chosen_var['oracle'] = np.arange(0, dat.shape[1], 1)

model_names = ['logistic', 'tree', 'gbm', 'rf', 'nnet', 'svm', 'knn']

class LogisticModel:
    
    def __init__(self):
        self.model = None
        
    def fit(self, X, y):
        self.model = l1_logistic.cv_fit(X, y, n_fold=5, penalty_scale=25, len_grid=25)
    
    def predict(self, X):
        return self.model.predict(X)

models = dict()
models['logistic'] = LogisticModel()
models['tree'] = DecisionTreeClassifier()
models['gbm'] = sklearn.ensemble.GradientBoostingClassifier()
models['rf'] = sklearn.ensemble.RandomForestClassifier(n_estimators=200, max_features='sqrt')
models['nnet'] = MLPClassifier(max_iter=2000)
models['svm'] = SVC()
models['knn'] = KNeighborsClassifier(p=3)

models_switch = dict()
models_switch['logistic'] = True
models_switch['tree'] = True
models_switch['gbm'] = True
models_switch['rf'] = True
models_switch['nnet'] = True
models_switch['svm'] = True
models_switch['knn'] = False

models_id = dict()
idx = 0
for m in model_names:
    models_id[m] = idx
    idx += 1


class_err = np.ones((0, len(model_names), len(screening_methods)))
num_chosen = np.zeros((0, 2))
var_intersect = np.zeros((0, len(screening_methods), len(screening_methods)))

tmp_err = np.ones((1, len(model_names), len(screening_methods)))
tmp_chosen = np.zeros((1, 2))
tmp_intersect = np.zeros((1, len(screening_methods), len(screening_methods)))


def assess_model_with_screening(xtr, ytr, xtes, ytes, model, chosen_var, default_err):
    if len(chosen_var) == 0:
        return default_err
    model.fit(X=xtr[:, chosen_var], y=ytr)
    return np.mean(ytes != model.predict(X=xtes[:, chosen_var]))


import time
start = time.time()

fold = 0
for tr_index, tes_index in kf.split(X=x, y=y):
    # adding independent noise
    if p_ind_noise > 0:
        x_noise = x[:,np.random.choice(x.shape[1], size=p_ind_noise, replace=True)]
        x_noise = np.hstack([x, np.apply_along_axis(np.random.permutation, axis=0, arr=x_noise)])
    else:
        x_noise = x
    # adding dependent noise
    if p_cor_noise > 0:
        x_cor_noise = x[:,np.random.choice(x.shape[1], size=p_cor_noise, replace=True)]
        x_cor_noise = rho*x_cor_noise + np.sqrt(1-np.power(rho,2))*np.random.normal(size=(x_cor_noise.shape[0], p_cor_noise))
        x_noise = np.hstack([x_noise,x_cor_noise]) 
    xtr = x_noise[tr_index,:]; ytr = y[tr_index]
    xtes = x_noise[tes_index,:]; ytes = y[tes_index]
    chosen_var['no-screening'] = np.arange(0, xtr.shape[1], 1)
    # compute base error
    base_err = np.mean(ytes != 1*(np.mean(ytr) >= 0.5))
    # screen variable using metric learning
    if screeners_switch['metric-screen']:
        extractor = KernelExtractor.MetricLearner(batch_size=batch_size, penalty='user_defined', solver=solver, subgroup_lower=0, subgroup_upper=1, param_update_frac=1, l1_constraint=l1_bound)
        metric_path = KernelExtractorPath.MetricPath()
        gbm = sklearn.ensemble.GradientBoostingClassifier(n_estimators=n_estimators, learning_rate=learning_rate, max_depth=max_depth)
        var_list = metric_path.run_paths(num_paths=num_paths, screener=extractor, model=gbm, X=xtr, class_p=ytr, num_tries=num_tries, num_seen_cutoff=num_seen_cutoff, lam=lam, max_rounds=max_rounds,verbose=True, init_value=5*lam, hierarchical=False, hier_upper=3, warm_start=warm_start, beta_init = 'equal', weight_update=weight_update, max_iter=max_iter, convergence_tol=convergence_tol,
                                        take_top_k=take_top_k, pi_hat_bound = pi_hat_bound, min_times_on_path=min_times_on_path, target_num_var=target_num_var)
        chosen_var['metric-screen'] = metric_path.get_selected_vars_as_array(0)
        print("Ranked list: ", metric_path.get_ranked_var_list(1))
        tmp_chosen[0, 1] = len(chosen_var['metric-screen'])
        print("%d variables chosen by metric learner out of %d total." % (len(chosen_var['metric-screen']), xtr.shape[1]))
        num_retain = len(chosen_var['metric-screen'])
    # screening with l1 logistic regression
    if screeners_switch['lasso-screen']:
        logreg = linear_model.LogisticRegression(penalty='l1', solver='liblinear', tol=1e-3,                                               max_iter=int(1e3), warm_start=True)
        chosen_var['lasso-screen'] = l1_logistic.find_topK_lasso(num_retain, model=logreg, X=xtr, y=ytr)
        tmp_chosen[0, 0] = len(chosen_var['lasso-screen'])   
        print("%d variables chosen by lasso out of %d total." % (len(chosen_var['lasso-screen']), xtr.shape[1]))
    # screening using random forest variable importance
    if screeners_switch['tree-screen']:
        models['rf'].fit(X=xtr, y=ytr)
        chosen_var['tree-screen'] = np.argsort(models['rf'].feature_importances_)[-num_retain:]
    # screening using t-statistic
    if screeners_switch['t-screen']:
        _, t_pval = scipy.stats.ttest_ind(xtr[ytr==0,:],xtr[ytr==1,:], axis=0)
        chosen_var['t-screen'] = np.argsort(t_pval)[:num_retain]
    for screen in screening_methods:
        for mod in model_names:
            if screeners_switch[screen] and models_switch[mod]:
                col_id = screeners_id[screen]
                row_id = models_id[mod]
                tmp_err[0, row_id, col_id] = assess_model_with_screening(xtr, ytr, xtes, ytes, models[mod],
                                                                         chosen_var[screen], base_err)
    for screen1 in screening_methods:
        for screen2 in screening_methods:
            if screeners_switch[screen1] and screeners_switch[screen2]:
                col_id = screeners_id[screen2]
                row_id = screeners_id[screen1]
                tmp_intersect[0, row_id, col_id] = len(np.intersect1d(chosen_var[screen1], chosen_var[screen2])) / len(
                    chosen_var[screen1]) if len(chosen_var[screen1]) > 0 else 0
    class_err = np.vstack([class_err, tmp_err])
    num_chosen = np.vstack([num_chosen, tmp_chosen])
    var_intersect = np.vstack([var_intersect, tmp_intersect])
    sim_results = dict()
    sim_results['num_chosen'] = num_chosen
    sim_results['class_err'] = class_err
    sim_results['var_intersect'] = var_intersect
    with open('./results/' + dataset_name + '_n' + str(max_n) + '_indnoise_' + str(p_ind_noise) + '_cornoise_'
              + str(p_cor_noise) + '_' + str(jobid) + '.pickle', 'wb') as handle:
        pickle.dump(sim_results, handle)


end = time.time()
print(end - start)